﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    private int num;

    private int countGuess;

    [SerializeField]
    private GameObject btn;

    [SerializeField]
    private InputField input;

    [SerializeField]
    private Text text;

    private void Awake()
    {
        num = Random.Range(1, 9);
        text.text = "Guess A Number Between 0 and 9";

         Debug.Log("System Number " + num);
    }


    public void GetInput(string guess)
    {
        //Debug.Log("You Entered " + guess);
        CompareGuesses(int.Parse(guess));
        input.text = "";
        countGuess++;
    }


    void CompareGuesses(int guess)
    {
        if (guess == num)
        {
            // SceneManager.LoadScene("");
        }

        else if (guess != num)
        {
            // SceneManager.LoadScene("");
        }
    }

    public void PlayAgain()
    {
        SceneManager.LoadScene("GameScene");
    }
}
